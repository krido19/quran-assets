// App State
const state = {
    currentView: 'view-quran',
    location: null,
    prayerTimes: null,
    qiblaOffset: 0
};

// DOM Elements
const views = document.querySelectorAll('.view');
const navItems = document.querySelectorAll('.nav-item');
const pageTitle = document.getElementById('page-title');

// Navigation Logic
navItems.forEach(item => {
    item.addEventListener('click', () => {
        const targetId = item.dataset.target;
        switchView(targetId);
    });
});

function switchView(viewId) {
    // Update State
    state.currentView = viewId;

    // Update UI
    views.forEach(view => view.classList.remove('active'));
    document.getElementById(viewId).classList.add('active');

    navItems.forEach(item => {
        if (item.dataset.target === viewId) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });

    // Update Title
    switch (viewId) {
        case 'view-quran': pageTitle.textContent = 'Al Quran'; break;
        case 'view-prayer': pageTitle.textContent = 'Prayer Times'; initPrayerTimes(); break;
        case 'view-qibla': pageTitle.textContent = 'Qibla Direction'; initQibla(); break;
    }
}

// --- Quran Feature ---
async function initQuran() {
    const listContainer = document.getElementById('surah-list');
    try {
        const response = await fetch('https://api.quran.com/api/v4/chapters?language=en');
        const data = await response.json();

        listContainer.innerHTML = ''; // Clear loading

        data.chapters.forEach(surah => {
            const el = document.createElement('div');
            el.className = 'surah-item';
            el.innerHTML = `
                <div class="surah-number">${surah.id}</div>
                <div class="surah-info">
                    <div class="surah-name-en">${surah.name_simple}</div>
                    <div class="surah-details">${surah.translated_name.name} • ${surah.verses_count} Verses</div>
                </div>
                <div class="surah-name-ar">${surah.name_arabic}</div>
            `;
            // Add click event for detail view (future implementation)
            el.addEventListener('click', () => {
                alert(`Opening Surah ${surah.name_simple} (Detail view coming soon)`);
            });
            listContainer.appendChild(el);
        });
    } catch (error) {
        listContainer.innerHTML = '<div style="text-align:center; padding:20px; color:red;">Failed to load Quran data. Check internet connection.</div>';
        console.error(error);
    }
}

// --- Prayer Times Feature ---
function initPrayerTimes() {
    if (!state.location) {
        getLocation();
    } else {
        renderPrayerTimes();
    }
}

function getLocation() {
    const listContainer = document.getElementById('prayer-times-list');
    listContainer.innerHTML = '<div style="text-align:center; padding:20px;">Locating...</div>';

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            position => {
                state.location = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude
                };
                renderPrayerTimes();
            },
            error => {
                console.warn("Geolocation failed, using default (Jakarta)", error);
                useDefaultLocation();
            },
            { timeout: 10000 }
        );
    } else {
        useDefaultLocation();
    }
}

function useDefaultLocation() {
    // Default to Jakarta, Indonesia
    state.location = {
        latitude: -6.2088,
        longitude: 106.8456
    };
    alert("Location access denied or failed. Using Jakarta as default.");
    renderPrayerTimes();
}

function renderPrayerTimes() {
    if (!state.location) return;

    const coordinates = new adhan.Coordinates(state.location.latitude, state.location.longitude);
    const params = adhan.CalculationMethod.MuslimWorldLeague();
    const date = new Date();
    const prayerTimes = new adhan.PrayerTimes(coordinates, date, params);

    const timeFormatter = new Intl.DateTimeFormat('en-US', {
        hour: 'numeric',
        minute: '2-digit',
    });

    const times = [
        { name: 'Fajr', time: prayerTimes.fajr },
        { name: 'Sunrise', time: prayerTimes.sunrise },
        { name: 'Dhuhr', time: prayerTimes.dhuhr },
        { name: 'Asr', time: prayerTimes.asr },
        { name: 'Maghrib', time: prayerTimes.maghrib },
        { name: 'Isha', time: prayerTimes.isha },
    ];

    const listContainer = document.getElementById('prayer-times-list');
    listContainer.innerHTML = '';

    const nextPrayer = prayerTimes.nextPrayer();
    const nextPrayerTime = prayerTimes.timeForPrayer(nextPrayer);

    // Update Header Card
    if (nextPrayer !== adhan.Prayer.None) {
        document.getElementById('next-prayer-name').textContent = capitalize(nextPrayer);
        startCountdown(nextPrayerTime);
    } else {
        document.getElementById('next-prayer-name').textContent = "Fajr (Tomorrow)";
        document.getElementById('countdown').textContent = "--:--:--";
    }

    // Render List
    times.forEach(p => {
        const el = document.createElement('div');
        el.className = `prayer-row ${nextPrayer === p.name.toLowerCase() ? 'active' : ''}`;
        el.innerHTML = `
            <span>${p.name}</span>
            <span>${timeFormatter.format(p.time)}</span>
        `;
        listContainer.appendChild(el);
    });
}

function startCountdown(targetTime) {
    const el = document.getElementById('countdown');

    const update = () => {
        const now = new Date();
        const diff = targetTime - now;

        if (diff <= 0) {
            el.textContent = "00:00:00";
            return;
        }

        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);

        el.textContent = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
    };

    update();
    setInterval(update, 1000);
}

// --- Qibla Feature ---
function initQibla() {
    if (!state.location) {
        getLocation();
        return;
    }

    // Calculate Qibla Direction
    const coordinates = new adhan.Coordinates(state.location.latitude, state.location.longitude);
    const qiblaDirection = adhan.Qibla(coordinates);
    document.getElementById('qibla-degree').textContent = Math.round(qiblaDirection) + "°";

    // Device Orientation for Compass
    if (window.DeviceOrientationEvent) {
        window.addEventListener('deviceorientation', function (event) {
            let compass = event.webkitCompassHeading || Math.abs(event.alpha - 360);

            // Calculate rotation needed to point to Qibla
            // If compass points North (0), and Qibla is at 295 (NW)
            // We need to rotate the arrow: Qibla - Compass

            const arrow = document.getElementById('qibla-arrow');
            arrow.style.transform = `rotate(${qiblaDirection - compass}deg)`;
        }, true);
    } else {
        alert("Device orientation not supported.");
    }
}

// Utils
function capitalize(s) {
    if (typeof s !== 'string') return '';
    return s.charAt(0).toUpperCase() + s.slice(1);
}

function pad(n) {
    return n < 10 ? '0' + n : n;
}

// Init
initQuran();
